import 'package:flutter/material.dart';

class FontStyles {
  String fontFamily = 'K2D';
  FontStyles() : super();
}
