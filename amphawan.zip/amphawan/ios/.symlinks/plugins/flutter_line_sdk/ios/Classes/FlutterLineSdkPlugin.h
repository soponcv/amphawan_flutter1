#import <Flutter/Flutter.h>

@interface FlutterLineSdkPlugin : NSObject<FlutterPlugin>
@end
