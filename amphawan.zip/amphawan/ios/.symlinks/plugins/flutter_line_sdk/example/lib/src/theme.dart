import 'package:flutter/material.dart';

const Color textColor = Colors.white;
const Color accentColor = const Color(0xFF58BF38);
const Color darkAccentColor = const Color(0xFF50AF33);
